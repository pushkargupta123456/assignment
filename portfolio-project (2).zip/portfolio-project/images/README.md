<!-- This is a placeholder for your profile image -->
<!-- To add your actual profile photo: -->
<!-- 1. Save your profile photo as 'profile-photo.jpg' in the 'images' folder -->
<!-- 2. Make sure the image is square (recommended: 400x400 pixels or larger) -->
<!-- 3. The CSS will automatically make it circular and resize it -->

<!-- For now, you can use a placeholder service or add your own image -->
<!-- Example placeholder URL: https://via.placeholder.com/400x400/3498db/ffffff?text=Your+Photo -->